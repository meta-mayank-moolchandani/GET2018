const sum = (a, b) => {
    return a + b;
};

const product = (a, b) => {
    return a * b;
};

const add = (a, b) => (b===undefined) ? a + b : (b) => a + b;

/**
  function add(a,b){
	if(b===undefined){
		return function(b){
			return a+b;
		}
	}else{
		return a+b;
	}
}
 */

 /**
   
  */


export {sum , product , add};

